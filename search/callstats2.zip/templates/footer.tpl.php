<div id="footer">
<p>
	<a href="http://code.google.com/p/asterisk-cdr-viewer/">Asterisk CDR viewer ( v.1.0.1 )</a>
    <!-- by Igor Okunev ( igor.okunev [at] gmail.com ) -->
</p>
</div>
</body>
</html>
